import headerlogo from "./header-logo.jpg";
import iitroorkee from "./iit-roorkee.jpeg";
import user from "./userlogo.svg";
import profile from "./profile.svg";

export { headerlogo, iitroorkee, user as userimg, profile };
